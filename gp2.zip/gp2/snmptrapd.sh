#!/bin/bash

MIB_OPTIONS="-M +/gpx/gp2/mibs -m ALL"

set -x
snmptrapd $MIB_OPTIONS -f -Lo -C -c /gpx/gp2/snmptrapd.p2.conf 
