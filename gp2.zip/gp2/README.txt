# ==================================================================
#		UNIVERSIDAD DE ALCALA
#		DEPARTAMENTO DE AUTOMATICA
#		AREA TELEMATICA
#
# Subject:	NETWORKS MANAGEMENT (GESTION DE RED)
#
# ==================================================================
#		PRACTICE DESCRIPTION AND INSTRUCTIONS
# ==================================================================
# Author: Alvaro Paricio Garcia (alvaro.paricio@uah.es)
# January 2013
# Copyright by author. All rights reserved.
# Licensed exclusively for academic purposes under GNU's GPLv3 license.
# (http://www.gnu.org/licenses/gpl.html)
# -Please note that this disclaimer MUST be in all cases preserved-
# ==================================================================

# ==================================================================
# TITLE: ASYNCHRONOUS NOTIFICATIONS MANAGEMENT - BASIC TRAPS -
# ==================================================================
